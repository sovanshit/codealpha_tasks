# Language-Translator

- Results:
![](https://github.com/sovanshit/Language-Translator/blob/main/Language-Translator/Result.png)
