# faq-chatbot

FAQ Chatbot is a machine learning based chatbot trained on FAQ [dataset](https://www.kaggle.com/datasets/abbbhishekkk/faq-datasets-for-chatbot-training) of Addhar.

- Libraries used:
  - Scikit-Learn
  - NLTK
  - Re
  - Numpy
  - Pandas
  - NLPAug

- Results:
![](https://github.com/sovanshit/Chtabot/blob/main/faq-chatbot-main/Prediction.png)
